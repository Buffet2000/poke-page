import{L as e,_ as n}from"../chunks/0.CpRqi0AA.js";export{e as component,n as universal};
