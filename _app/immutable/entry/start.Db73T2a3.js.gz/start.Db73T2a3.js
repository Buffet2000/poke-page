import{a as t}from"../chunks/entry.DlovqUGW.js";export{t as start};
